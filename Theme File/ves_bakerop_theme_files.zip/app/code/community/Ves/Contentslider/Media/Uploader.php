<?php
class Ves_Contentslider_Media_Uploader extends Varien_File_Uploader
{   
}