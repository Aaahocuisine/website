<?php

$installer = $this;
/* @var $installer Mage_Core_Model_Resource_Setup */
/*
$installer->startSetup();

$installer->run("
	ALTER TABLE {$this->getTable('ves_blog/post')} DROP INDEX `identifier`;
	ALTER TABLE {$this->getTable('ves_blog/category')} DROP INDEX `identifier`;
");
*/
