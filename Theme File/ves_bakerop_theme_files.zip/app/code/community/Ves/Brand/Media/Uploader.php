<?php
class Ves_Brand_Media_Uploader extends Varien_File_Uploader
{   
}