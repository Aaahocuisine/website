<?php
class Ves_ProductCategories_Helper_Data extends Mage_Core_Helper_Abstract {

}